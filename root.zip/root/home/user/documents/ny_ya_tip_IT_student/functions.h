#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <string>

void displayFileContent(const std::string& filename);
void appendToFile(const std::string& filename);
void readNumberByIndex(const std::string& filename);
void countNumbersInFile(const std::string& filename);
void createNewFileWithNumbersCount(const std::string& filename);

#endif
